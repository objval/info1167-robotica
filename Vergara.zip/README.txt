Nicolas Vergara Von dem Knesebeck
INFO1167 - Robotica
